# Sistema web de gestión de instrumentos musicales (HU-03 y HU-08)

## Cómo probarlo
1. Crear la base en PostgreSQL: `createdb instrumentos_musicales` (usuario/clave en `config/settings.py`).
2. Instalar solo el stack indicado: `pip install django psycopg[binary]`.
3. `python manage.py makemigrations inventario && python manage.py migrate`
4. `python manage.py test` (pruebas automáticas de ambas historias)
5. `python manage.py runserver` y abrir `/instrumentos/nuevo/` (HU-03) y `/arriendos/nuevo/` (HU-08).
   Para HU-08 hace falta al menos un cliente: `python manage.py shell` y crear un `Cliente`.

## Plan de implementación (6 pasos)
1. Usar los modelos existentes sin modificarlos (`models.py`).
2. Escribir las reglas puras (días y tarifa) en `servicios.py`.
3. Crear los formularios con validaciones (`forms.py`).
4. Crear las vistas con mensajes y transacción (`views.py`).
5. Definir rutas y plantillas (`urls.py`, `templates/`).
6. Cubrir cada criterio con pruebas (`tests.py`).

## Criterios cubiertos
HU-03: 1 `InstrumentoForm.Meta.fields` · 2 `required` + mensaje · 3 `clean_numero_serie` · 4 `clean_tarifa_diaria` · 5 `estado="disponible"` en la vista · 6 `messages.success` · 7 redirección al catálogo con `NoReverseMatch` · 8 el botón Cancelar es un enlace: no envía el formulario.
HU-08: 1 `required` · 2 `initial=date.today` · 3 `clean()` fechas · 4 `clean()` estado del instrumento · 5 `calcular_tarifa_total` · 6 `transaction.atomic` + `select_for_update` · 7 Cancelar no envía el formulario · 8 `messages.success` con la tarifa.
