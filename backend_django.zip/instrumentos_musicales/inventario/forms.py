"""Formularios de HU-03 (Registrar instrumento) y HU-08 (Registrar arriendo)."""
from datetime import date

from django import forms

from .models import Arriendo, Cliente, Instrumento


class InstrumentoForm(forms.ModelForm):
    """HU-03. El campo 'estado' no se muestra: el sistema asigna 'disponible'."""

    class Meta:
        model = Instrumento
        fields = ["numero_serie", "marca", "modelo", "tipo",
                  "estado_conservacion", "tarifa_diaria"]  # criterios 1 y 5
        labels = {"numero_serie": "Número de serie", "estado_conservacion": "Estado de conservación",
                  "tarifa_diaria": "Tarifa diaria"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for campo in self.fields.values():
            campo.required = True
            campo.error_messages["required"] = "Este campo es obligatorio."  # criterio 2

    def clean_numero_serie(self):  # criterio 3
        serie = self.cleaned_data["numero_serie"].strip()
        if Instrumento.objects.filter(pk=serie).exists():
            raise forms.ValidationError("Ya existe un instrumento con ese número de serie.")
        return serie

    def clean_tarifa_diaria(self):  # criterio 4
        tarifa = self.cleaned_data["tarifa_diaria"]
        if tarifa <= 0:
            raise forms.ValidationError("La tarifa diaria debe ser mayor que 0.")
        return tarifa


class ArriendoForm(forms.ModelForm):
    """HU-08. La tarifa total no se escribe: se calcula al guardar."""

    class Meta:
        model = Arriendo
        fields = ["cliente", "instrumento", "fecha_inicio", "fecha_retorno_programada"]
        widgets = {"fecha_inicio": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
                   "fecha_retorno_programada": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d")}
        labels = {"fecha_inicio": "Fecha de inicio",
                  "fecha_retorno_programada": "Fecha de retorno programada"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["fecha_inicio"].initial = date.today  # criterio 2: hoy, modificable
        for campo in self.fields.values():
            campo.required = True
            campo.error_messages["required"] = "Este campo es obligatorio."  # criterio 1

    def clean(self):
        datos = super().clean()
        inicio = datos.get("fecha_inicio")
        retorno = datos.get("fecha_retorno_programada")
        instrumento = datos.get("instrumento")
        if inicio and retorno and retorno < inicio:  # criterio 3
            self.add_error("fecha_retorno_programada",
                           "La fecha de retorno no puede ser anterior a la fecha de inicio.")
        if instrumento and instrumento.estado != "disponible":  # criterio 4
            self.add_error("instrumento",
                           f"El instrumento no está disponible (estado actual: {instrumento.get_estado_display()}).")
        return datos
