"""Modelos que YA EXISTEN en el proyecto (HU-03 y HU-08 no los modifican)."""
from django.db import models


class Instrumento(models.Model):
    TIPOS = [("cuerda", "Cuerda"), ("viento", "Viento"), ("percusion", "Percusión"),
             ("teclado", "Teclado"), ("otro", "Otro")]
    CONSERVACION = [("nuevo", "Nuevo"), ("bueno", "Bueno"), ("regular", "Regular")]
    ESTADOS = [("disponible", "Disponible"), ("arrendado", "Arrendado"),
               ("en_mantencion", "En mantención"), ("de_baja", "De baja")]

    numero_serie = models.CharField(max_length=40, primary_key=True)  # clave natural
    marca = models.CharField(max_length=60)
    modelo = models.CharField(max_length=60)
    tipo = models.CharField(max_length=20, choices=TIPOS)
    estado_conservacion = models.CharField(max_length=20, choices=CONSERVACION)
    tarifa_diaria = models.DecimalField(max_digits=10, decimal_places=0)
    estado = models.CharField(max_length=20, choices=ESTADOS, default="disponible")

    def __str__(self):
        return f"{self.marca} {self.modelo} ({self.numero_serie})"


class Cliente(models.Model):
    rut = models.CharField(max_length=12, primary_key=True)  # clave natural
    nombre = models.CharField(max_length=100)
    correo = models.EmailField(unique=True)
    telefono = models.CharField(max_length=20)
    consentimiento_datos = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.nombre} ({self.rut})"


class Arriendo(models.Model):
    cliente = models.ForeignKey(Cliente, on_delete=models.PROTECT)
    instrumento = models.ForeignKey(Instrumento, on_delete=models.PROTECT)
    fecha_inicio = models.DateField()
    fecha_retorno_programada = models.DateField()
    tarifa_total = models.DecimalField(max_digits=12, decimal_places=0)
