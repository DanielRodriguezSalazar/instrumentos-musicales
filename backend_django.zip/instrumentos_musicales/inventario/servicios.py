"""Reglas de negocio puras (sin Django), fáciles de probar."""
from datetime import date
from decimal import Decimal


def dias_de_arriendo(fecha_inicio: date, fecha_retorno: date) -> int:
    """Días a cobrar: diferencia de fechas, con un mínimo de 1 día."""
    return max(1, (fecha_retorno - fecha_inicio).days)


def calcular_tarifa_total(fecha_inicio: date, fecha_retorno: date, tarifa_diaria) -> Decimal:
    """Tarifa total = días de arriendo x tarifa diaria del instrumento."""
    return dias_de_arriendo(fecha_inicio, fecha_retorno) * Decimal(tarifa_diaria)
