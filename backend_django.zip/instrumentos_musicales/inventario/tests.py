"""Pruebas de HU-03 y HU-08. Ejecutar: python manage.py test"""
from datetime import date, timedelta
from decimal import Decimal

from django.test import SimpleTestCase, TestCase
from django.urls import reverse

from .models import Arriendo, Cliente, Instrumento
from .servicios import calcular_tarifa_total, dias_de_arriendo

DATOS = {"numero_serie": "GT-001", "marca": "Fender", "modelo": "Stratocaster", "tipo": "cuerda",
         "estado_conservacion": "bueno", "tarifa_diaria": "8000"}


class ServiciosTest(SimpleTestCase):
    def test_minimo_un_dia(self):
        hoy = date.today()
        self.assertEqual(dias_de_arriendo(hoy, hoy), 1)

    def test_tarifa_total(self):
        hoy = date.today()
        self.assertEqual(calcular_tarifa_total(hoy, hoy + timedelta(days=3), 8000), Decimal(24000))


class RegistrarInstrumentoTest(TestCase):
    url = "registrar_instrumento"

    def test_guarda_con_estado_disponible(self):
        self.client.post(reverse(self.url), DATOS)
        self.assertEqual(Instrumento.objects.get(pk="GT-001").estado, "disponible")

    def test_campo_vacio_rechaza(self):
        self.client.post(reverse(self.url), {**DATOS, "marca": ""})
        self.assertEqual(Instrumento.objects.count(), 0)

    def test_serie_repetida_rechaza(self):
        self.client.post(reverse(self.url), DATOS)
        r = self.client.post(reverse(self.url), DATOS)
        self.assertContains(r, "Ya existe un instrumento")
        self.assertEqual(Instrumento.objects.count(), 1)

    def test_tarifa_cero_rechaza(self):
        self.client.post(reverse(self.url), {**DATOS, "tarifa_diaria": "0"})
        self.assertEqual(Instrumento.objects.count(), 0)

    def test_get_no_guarda_nada(self):  # cancelar = no enviar el formulario
        self.client.get(reverse(self.url))
        self.assertEqual(Instrumento.objects.count(), 0)


class RegistrarArriendoTest(TestCase):
    def setUp(self):
        self.instrumento = Instrumento.objects.create(
            numero_serie="GT-001", marca="Fender", modelo="Strat", tipo="cuerda",
            estado_conservacion="bueno", tarifa_diaria=8000)
        self.cliente = Cliente.objects.create(
            rut="11.111.111-1", nombre="Ana Pérez", correo="ana@correo.cl", telefono="+56911112222",
            consentimiento_datos=True)
        hoy = date.today()
        self.datos = {"cliente": self.cliente.pk, "instrumento": self.instrumento.pk,
                      "fecha_inicio": hoy.isoformat(), "fecha_retorno_programada": (hoy + timedelta(days=3)).isoformat()}

    def test_guarda_calcula_tarifa_y_cambia_estado(self):
        self.client.post(reverse("registrar_arriendo"), self.datos)
        arriendo = Arriendo.objects.get()
        self.assertEqual(arriendo.tarifa_total, 24000)
        self.instrumento.refresh_from_db()
        self.assertEqual(self.instrumento.estado, "arrendado")

    def test_instrumento_no_disponible_rechaza(self):
        Instrumento.objects.filter(pk="GT-001").update(estado="en_mantencion")
        r = self.client.post(reverse("registrar_arriendo"), self.datos)
        self.assertContains(r, "no está disponible")
        self.assertEqual(Arriendo.objects.count(), 0)

    def test_retorno_anterior_rechaza(self):
        self.datos["fecha_retorno_programada"] = (date.today() - timedelta(days=1)).isoformat()
        self.client.post(reverse("registrar_arriendo"), self.datos)
        self.assertEqual(Arriendo.objects.count(), 0)

    def test_cancelar_no_cambia_estado(self):
        self.client.get(reverse("registrar_arriendo"))
        self.instrumento.refresh_from_db()
        self.assertEqual(self.instrumento.estado, "disponible")
