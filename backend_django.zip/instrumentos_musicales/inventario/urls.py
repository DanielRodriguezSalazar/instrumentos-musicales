from django.urls import path

from . import views

urlpatterns = [
    path("instrumentos/", views.catalogo, name="catalogo"),
    path("instrumentos/nuevo/", views.registrar_instrumento, name="registrar_instrumento"),
    path("arriendos/nuevo/", views.registrar_arriendo, name="registrar_arriendo"),
]
