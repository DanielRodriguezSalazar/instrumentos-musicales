"""Vistas de HU-03 y HU-08."""
from django.contrib import messages
from django.db import transaction
from django.shortcuts import redirect, render
from django.urls import NoReverseMatch, reverse

from .forms import ArriendoForm, InstrumentoForm
from .models import Instrumento
from .servicios import calcular_tarifa_total


def registrar_instrumento(request):
    """HU-03: registra un instrumento; el estado se asigna solo ('disponible')."""
    if request.method == "POST":
        formulario = InstrumentoForm(request.POST)
        if formulario.is_valid():
            instrumento = formulario.save(commit=False)
            instrumento.estado = "disponible"  # criterio 5
            instrumento.save()
            messages.success(request, f"Instrumento {instrumento.numero_serie} registrado correctamente.")  # criterio 6
            try:  # criterio 7: si el catálogo no existe, no se bloquea la operación
                return redirect(reverse("catalogo"))
            except NoReverseMatch:
                return redirect("registrar_instrumento")
    else:
        formulario = InstrumentoForm()
    return render(request, "inventario/registrar_instrumento.html", {"formulario": formulario})


def registrar_arriendo(request):
    """HU-08: registra el arriendo, calcula la tarifa y marca el instrumento como arrendado."""
    if request.method == "POST":
        formulario = ArriendoForm(request.POST)
        if formulario.is_valid():
            with transaction.atomic():  # criterio 6: todo o nada
                instrumento = Instrumento.objects.select_for_update().get(pk=formulario.cleaned_data["instrumento"].pk)
                if instrumento.estado != "disponible":  # revalida dentro de la transacción
                    formulario.add_error("instrumento", "El instrumento ya no está disponible.")
                else:
                    arriendo = formulario.save(commit=False)
                    arriendo.tarifa_total = calcular_tarifa_total(  # criterio 5
                        arriendo.fecha_inicio, arriendo.fecha_retorno_programada, instrumento.tarifa_diaria)
                    arriendo.save()
                    instrumento.estado = "arrendado"
                    instrumento.save(update_fields=["estado"])
                    messages.success(request, f"Arriendo registrado. Tarifa total: ${arriendo.tarifa_total:,.0f}")  # criterio 8
                    return redirect("registrar_arriendo")
    else:
        formulario = ArriendoForm()
    return render(request, "inventario/registrar_arriendo.html", {"formulario": formulario})


def catalogo(request):
    """Catálogo mínimo ASUMIDO por el contexto (solo para que el proyecto de ejemplo funcione)."""
    return render(request, "inventario/catalogo.html", {"instrumentos": Instrumento.objects.all()})
