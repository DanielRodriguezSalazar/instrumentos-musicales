#!/usr/bin/env python
"""Utilidad de línea de comandos de Django."""
import os
import sys


def principal():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    principal()
